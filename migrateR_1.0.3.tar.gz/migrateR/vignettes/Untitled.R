require(migrateR)
require(adehabitatLT)

?mvmtClass

data(bighorn)
bhs.elev<-mvmtClass(bighorn,typ="elev")

bhs.elev.stdt <- mvmtClass(bighorn, typ="elev",stdt="10-31")

p.elev <- mvmt2tbl(bhs.elev)$migrant
p.elev.stdt <- mvmt2tbl(bhs.elev.std)$migrant

round(p.elev - p.elev.std,2)


test <- mvmtClass(bighorn)
 str(test)

plot.mvmt
plot(test,new=T)

