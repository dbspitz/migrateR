## ----setup, include=FALSE------------------------------------------------
require(migrateR)

## ----, fig.width = 7.5, fig.height = 3.5, echo=FALSE, warning=F----------
source("/users/jacobim/documents/hal/packages/migrater/vignettes/elvnsdmodelsplot.r")

## ------------------------------------------------------------------------
require(migrateR)
data(bighorn)
bighorn

## ----, warning=FALSE-----------------------------------------------------
  bhs.nsd <- mvmtClass(bighorn, stdt = "10-31")

## ----, warning=FALSE-----------------------------------------------------
  bhs.elev <- mvmtClass(bighorn, fam = "elev", stdt = "10-31")

## ----echo=FALSE----------------------------------------------------------
  bhs.nsd <- mvmtClass(bighorn, stdt = "10-31")

## ------------------------------------------------------------------------
!fullmvmt(bhs.nsd)

## ------------------------------------------------------------------------
fullmvmt(bhs.nsd, out = "numer")

## ------------------------------------------------------------------------
fullmvmt(bhs.nsd, out = "name")

## ------------------------------------------------------------------------
  pest.n2 <- pEst(s.d = 15)
  bhs.nsd2 <- mvmtClass(bighorn, stdt = "10-31", p.est = pest.n2)
  all(fullmvmt(bhs.nsd2))

## ------------------------------------------------------------------------
   fullmvmt(bhs.elev)
   pest.e2 <- pEst(s.d = -500)
   bhs.elev2 <- refine(bhs.elev, p.est = pest.e2)
   all(fullmvmt(bhs.elev2))

## ----, fig.height=4, fig.width=7, echo=FALSE-----------------------------
plot(bhs.nsd[[3]])

## ----, fig.height=4, fig.width=7, echo=T---------------------------------
plot(bhs.elev[[3]])

## ----, fig.width = 7.5, fig.height = 3.5---------------------------------
   pest.e3 <- pEst(u.d = 0)
   bhs.elev3<- refine(bhs.elev, p.est = pest.e3)
   plot(bhs.elev3[[3]])

## ----, fig.width=7.5, fig.height=3.5-------------------------------------
spatmig(bighorn[2], bhs.nsd[2])


## ------------------------------------------------------------------------
bhs.nsd2

## ------------------------------------------------------------------------
top.bhs.nsd2 <- topmvmt(bhs.nsd2)
bhs.nsd2.behavior <- names(top.bhs.nsd2)
table(bhs.nsd2.behavior)

## ------------------------------------------------------------------------
summary(bhs.elev3)  # default classification shown under "topmod"

top.bhs.elev3 <- topmvmt(bhs.elev3, mrho = 21, mdelta = 500)
table(names(top.bhs.elev3))

## ----, fig.width=7.5, fig.height=3.5,echo=FALSE--------------------------
par(mfrow=c(1,2))
plot(bhs.elev3[[1]])
plot(bhs.elev3[[2]])

## ------------------------------------------------------------------------
p.bhs.nsd2 <- mvmt2df(top.bhs.nsd2)
p.bhs.nsd2

## ------------------------------------------------------------------------
t2 <- theta2(bhs.nsd2)
t2

## ----,echo=FALSE---------------------------------------------------------
par(mfrow=c(1,1))

## ----, fig.width = 7.5, fig.height = 3.5---------------------------------
plot(bhs.nsd[[3]])
abline(v = t2[3,1], lty = 2, lw = 2)

## ------------------------------------------------------------------------
d2 <- delta2(bhs.nsd2)
d2

## ----, fig.width = 7.5, fig.height = 3.5---------------------------------
plot(bhs.nsd2[[2]])
d <- coef(bhs.nsd2[[2]]@models$mixmig)["delta"]
abline(h = d-d2[2,1], lty = 2, lw = 2)

## ------------------------------------------------------------------------
mvmt2dt(bhs.nsd, mod = "mixmig")

## ------------------------------------------------------------------------
bhs3.nsd <- mvmtClass(bighorn[3], stdt = "10-31", ecut = "6-15")

## ----, fig.width = 7.5, fig.height = 3.5, echo=FALSE---------------------
par(mfrow=c(1,2))
plot(bhs.nsd2[[3]])
plot(bhs3.nsd[[1]])

## ----, warning=FALSE-----------------------------------------------------
rlocs <- findrloc(bighorn)
bhs.rnsd <- mvmtClass(bighorn, rloc = rlocs$rloc, stdt = "10-31", p.est = pest.n2)
bhs.rnsd2 <- refine(bhs.rnsd, pEst(s.t = 220))
fullmvmt(bhs.rnsd2,"name")


## ----, fig.width = 7.5, fig.height = 3.5, echo=FALSE---------------------
   par(mfrow=c(1,2))
   plot(bhs.nsd[[1]], ylim=c(0,45))
   plot(bhs.rnsd2[[1]], ylim=c(0,45))

## ----, echo=FALSE--------------------------------------------------------
bighorn

## ------------------------------------------------------------------------
bhs.elev0 <- mvmtClass(bighorn, fam = "elev", p.est = pest.e2)
bhs.elev0r1 <- refine(bhs.elev0, p.est = pest.e3)
fullmvmt(bhs.elev0r1, out = "name")

bhs.elev.stdt.mig <- topmvmt(bhs.elev3, omit = c("resident", "disperser"))
bhs.elev.mig <- topmvmt(bhs.elev0r1, omit = c("resident", "disperser"))

p.elev.stdt <- mvmt2df(bhs.elev.stdt.mig)
p.elev <- mvmt2df(bhs.elev.mig)

round(p.elev.stdt[[1]] - p.elev[[1]] ,2)

## ------------------------------------------------------------------------
  str(bhs.nsd[["s110 2010"]])

