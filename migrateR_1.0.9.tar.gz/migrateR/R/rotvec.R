rotvec <-
function(vec) vec[rot(length(vec))]
