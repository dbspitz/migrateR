rot <-
function(x) (1:x %% x) +1
